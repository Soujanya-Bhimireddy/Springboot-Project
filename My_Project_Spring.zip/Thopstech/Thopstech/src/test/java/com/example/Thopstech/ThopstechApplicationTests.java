package com.example.Thopstech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThopstechApplicationTests {

	@Test
	void contextLoads() {
	}

}
