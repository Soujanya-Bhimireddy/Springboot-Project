package com.example.Thopstech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThopstechApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThopstechApplication.class, args);
	}

}
